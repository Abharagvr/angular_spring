# Angular-app
Creating an Angular application from scratch
